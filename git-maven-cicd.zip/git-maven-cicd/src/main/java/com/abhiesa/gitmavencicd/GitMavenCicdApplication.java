package com.abhiesa.gitmavencicd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitMavenCicdApplication {

	public static void main(String[] args) {
		SpringApplication.run(GitMavenCicdApplication.class, args);
	}
}
